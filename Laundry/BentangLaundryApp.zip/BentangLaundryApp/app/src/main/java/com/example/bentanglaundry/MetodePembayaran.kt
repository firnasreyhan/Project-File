package com.example.bentanglaundry

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MetodePembayaran : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_metode_pembayaran)
    }
}