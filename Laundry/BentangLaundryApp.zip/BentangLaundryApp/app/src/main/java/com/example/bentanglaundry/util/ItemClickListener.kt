package com.example.bentanglaundry.util

interface ItemClickListener<T> {
    fun onClickItem(item : T)
}