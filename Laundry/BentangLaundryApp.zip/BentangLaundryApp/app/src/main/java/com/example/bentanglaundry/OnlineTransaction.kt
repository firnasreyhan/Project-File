package com.example.bentanglaundry

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class OnlineTransaction : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose_transaction)
    }
}