package com.example.bentanglaundry


import android.content.Intent
import android.os.Bundle
import android.os.Parcelable
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.bentanglaundry.history.HistoryAdapter
import com.example.bentanglaundry.history.HistoryModel
import com.example.bentanglaundry.retrofit.ApiService
import com.example.bentanglaundry.util.ItemClickListener
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.Serializable

class HistoryFragment : Fragment() {
    private val TAG:String = "History"

    lateinit var  historyAdapter: HistoryAdapter


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_history, container, false)

        setupRecylerView(view)
        getDataFromApi()

        return view
    }

    private fun setupRecylerView(view: View) {
        val recyclerhistory = view.findViewById<RecyclerView>(R.id.history_recycleview)
        historyAdapter = HistoryAdapter(object : ItemClickListener<HistoryModel.Result> {
            override fun onClickItem(item: HistoryModel.Result) {
                val intent = Intent(requireActivity(), DetailHistory::class.java)
//                intent.putExtra("intent_nama_pelanggan", item.nama_pelanggan)
//                intent.putExtra("intent_tgl_terima", item.tgl_terima)
//                intent.putExtra("intent_status_pencucian", item.status_pencucian)
//                intent.putExtra("intent_jenis_laundry", item.jenis_laundry)
//                intent.putExtra("intent_totalbayar", item.totalbayar)
                intent.putExtra("data", item)
                startActivity(intent)
            }
        })
        recyclerhistory.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = historyAdapter
        }
    }
    private fun getDataFromApi(){
        ApiService.endpoint.getDetail()
            .enqueue(object : Callback<HistoryModel> {

                override fun onResponse(
                    call: Call<HistoryModel>,
                    response: Response<HistoryModel>
                ) {
                    if (response.isSuccessful){
                        showDetail(response.body()!!)
                    }
                }

                override fun onFailure(call: Call<HistoryModel>, t: Throwable) {
                    printlog(t.toString())
                }

            })
    }

    private fun printlog(message: String){
        Log.d(TAG, message)
    }

    private fun showDetail(data: HistoryModel) {
        val results = data.result
        for (result in results) {
            printlog("Nama: ${result.nama_pelanggan}")
            historyAdapter.results.add(result)
        }
        historyAdapter.notifyDataSetChanged()
    }

}