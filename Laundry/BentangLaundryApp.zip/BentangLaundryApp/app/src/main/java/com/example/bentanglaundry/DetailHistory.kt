package com.example.bentanglaundry

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import com.example.bentanglaundry.history.HistoryModel

class DetailHistory : AppCompatActivity() {
    var data: HistoryModel.Result? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_history)

        data = intent.getSerializableExtra("data") as? HistoryModel.Result

        findViewById<TextView>(R.id.id_laundry).setText(data?.id_laundry.toString())
        findViewById<TextView>(R.id.nama_pelanggan).setText(data?.nama_pelanggan.toString())
        findViewById<TextView>(R.id.pelanggan_alamat).setText(data?.pelanggan_alamat.toString())
        findViewById<TextView>(R.id.pelanggan_jk).setText(data?.pelanggan_jk.toString())
        findViewById<TextView>(R.id.pelanggan_telp).setText(data?.pelanggan_telp.toString())
        findViewById<TextView>(R.id.tgl_selesai).setText(data?.tgl_selesai.toString())
        findViewById<TextView>(R.id.catatan).setText(data?.catatan.toString())
        findViewById<TextView>(R.id.status_pembayaran).setText(data?.status_pembayaran.toString())
        findViewById<TextView>(R.id.status_pengambilan).setText(data?.status_pengambilan.toString())
        findViewById<TextView>(R.id.status_pencucian).setText(data?.status_pencucian.toString())
        findViewById<TextView>(R.id.status_pencucian).setText(data?.status_pencucian.toString())
        findViewById<TextView>(R.id.tgl_terima).setText(data?.tgl_terima.toString())
        findViewById<TextView>(R.id.jenis_laundry).setText(data?.jenis_laundry.toString())
        findViewById<TextView>(R.id.tgl_selesai2).setText(data?.tgl_selesai.toString())
        findViewById<TextView>(R.id.jml_kilo).setText("${data?.jml_kilo.toString()} Kg")
        findViewById<TextView>(R.id.tarif).setText(data?.tarif.toString())
        findViewById<TextView>(R.id.totalbayar).setText(data?.totalbayar.toString())
    }
}