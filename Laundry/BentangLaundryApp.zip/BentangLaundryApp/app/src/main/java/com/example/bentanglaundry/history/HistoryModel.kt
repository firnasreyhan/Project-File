package com.example.bentanglaundry.history

import android.os.Parcelable
import java.io.Serializable

data class HistoryModel (
    val result: ArrayList<Result>
) {
    data class Result (val catatan: String,
                       val id_laundry: String,
                       val jenis_laundry: String,
                       val jml_kilo: String,
                       val nama_pelanggan: String,
                       val pelanggan_alamat: String,
                       val pelanggan_jk: String,
                       val pelanggan_telp: String,
                       val status_pembayaran: String,
                       val status_pencucian: String,
                       val status_pengambilan: String,
                       val tarif: String,
                       val tgl_selesai: String,
                       val tgl_terima: String,
                       val totalbayar: String
    ) : Serializable

}