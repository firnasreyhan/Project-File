<?php 

// ambil id dari url
$id = $_GET['id'];

// ubah status pencucian baju
$result = mysqli_query($conn, "UPDATE tb_laundry SET `status_pencucian` = 1 WHERE id_laundry = '$id'");

if ($result) {
  echo "
  <script>
    alert('Baju milik ID transaksi $id menuju pencucian');
    window.location.href = '?page=laundry';
  </script>
";
}
?>