<?php 
    require_once('helper.php');

    $id_laundry = $_POST['id_laundry'];

    $query  = "SELECT * FROM `tb_laundry` INNER JOIN `tb_pelanggan` ON `tb_laundry`.`id_pelanggan` = `tb_pelanggan`.`id_pelanggan` INNER JOIN `tb_users` ON `tb_users`.`id_user` = `tb_laundry`.`id_user` INNER JOIN `tb_jenis` ON `tb_jenis`.`kd_jenis` = `tb_laundry`.`kd_jenis` WHERE `tb_laundry`.`id_laundry` = '$id_laundry'";
    $sql    = mysqli_query($db_connect, $query);

    $result = array();

    while($row = mysqli_fetch_array($sql))
    {
        array_push($result, array(
           'id_laundry' => $row['id_laundry'],
           'nama_pelanggan' => $row['nama_pelanggan'],
           'pelanggan_alamat' => $row['pelanggan_alamat'],
           'pelanggan_jk' => $row['pelanggan_jk'],
           'pelanggan_telp' => $row['pelanggan_telp'],
           'tgl_selesai' => $row['tgl_selesai'],
           'catatan' => $row['catatan'],
           'status_pembayaran' => $row['status_pembayaran'],
           'status_pengambilan' => $row['status_pengambilan'],
           'status_pencucian' => $row['status_pencucian'],
           'username' => $row['username'],
           'tgl_terima' => $row['tgl_terima'],
           'jenis_laundry' => $row['jenis_laundry'],
           'jml_kilo' => $row['jml_kilo'],
           'tarif' => $row['tarif'],
           'totalbayar' => $row['totalbayar']
        ));
        
    }

    echo json_encode(array("result" => $result));

    
?>